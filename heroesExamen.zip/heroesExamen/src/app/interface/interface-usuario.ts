export interface InterfaceUsuario {
    username: string,
    password: string;
}
